/* NeatDownloadManager 排除网站选项页逻辑 */

function normalizeHost(input) {
  let s = String(input || "").trim();
  if (!s) return "";
  try {
    // 允许直接粘贴完整 URL，仅保留 hostname
    if (/^https?:\/\//i.test(s)) {
      return new URL(s).hostname.toLowerCase();
    }
  } catch (e) {}
  if (s.indexOf("://") !== -1) s = s.substring(s.indexOf("://") + 3);
  if (s.indexOf("/") !== -1) s = s.substring(0, s.indexOf("/"));
  s = s.replace(/^[a-z0-9.-]*@/i, ""); // 去掉 user@ 部分
  s = s.replace(/:.*$/, "");           // 去掉端口
  return s.toLowerCase();
}

let sites = []; // { host, full }

function render() {
  const list = document.getElementById("list");
  const empty = document.getElementById("empty");
  list.innerHTML = "";
  empty.classList.toggle("hidden", sites.length > 0);

  sites.forEach((site, i) => {
    const li = document.createElement("li");

    const info = document.createElement("div");
    const name = document.createElement("div");
    name.className = "site-name";
    name.textContent = site.host;
    info.appendChild(name);
    if (site.full && site.full !== site.host) {
      const full = document.createElement("div");
      full.className = "site-full";
      full.textContent = site.full;
      info.appendChild(full);
    }

    const btn = document.createElement("button");
    btn.className = "remove-btn";
    btn.type = "button";
    btn.textContent = "移除";
    btn.addEventListener("click", () => {
      sites.splice(i, 1);
      save();
      render();
    });

    li.appendChild(info);
    li.appendChild(btn);
    list.appendChild(li);
  });
}

function save() {
  chrome.storage.local.set({ neatExcludedSites: sites });
  // 通知后台立即重建缓存（不强制刷新，排除的站点在下次导航时生效）
  try { chrome.runtime.sendMessage({ type: "neatExcludedChange", refreshTabs: false }); } catch (e) {}
}

function addSite(raw) {
  const host = normalizeHost(raw);
  if (!host) {
    showError("请输入有效的域名。");
    return false;
  }
  if (sites.some(s => s.host === host)) {
    showError("该网站已在排除列表中。");
    return false;
  }
  sites.push({ host, full: String(raw || "").trim() });
  save();
  render();
  hideError();
  return true;
}

function showError(msg) {
  const el = document.getElementById("add-error");
  el.textContent = msg;
  el.classList.remove("hidden");
}

function hideError() {
  document.getElementById("add-error").classList.add("hidden");
}

document.getElementById("btn-add").addEventListener("click", () => {
  const input = document.getElementById("input-domain");
  if (addSite(input.value)) input.value = "";
});

document.getElementById("input-domain").addEventListener("keydown", e => {
  if (e.key === "Enter") {
    const input = document.getElementById("input-domain");
    if (addSite(input.value)) input.value = "";
  }
});

chrome.storage.local.get(["neatExcludedSites"], result => {
  sites = (result.neatExcludedSites || []).map(s => ({
    host: String(s.host || "").toLowerCase(),
    full: String(s.full || s.host || "")
  }));
  render();
});
