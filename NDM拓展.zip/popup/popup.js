/* NeatDownloadManager 工具栏弹窗逻辑 */

function closePopup() {
  try { window.close() } catch (e) {}
}

var excludeBtn = document.getElementById("exclude-current");
var btnTitle = document.getElementById("btn-title");
var btnSub = document.getElementById("btn-sub");

/* 查询当前标签页是否已被排除，决定显示"排除"还是"取消排除" */
chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  var tab = tabs && tabs[0];
  if (!tab || !tab.id || !tab.url || !/^https?:/i.test(tab.url)) {
    btnTitle.textContent = "无法在此页面使用";
    btnSub.textContent = "仅支持 http/https 网页";
    excludeBtn.style.opacity = .5;
    excludeBtn.style.cursor = "not-allowed";
    return;
  }
  chrome.runtime.sendMessage({ type: "neatIsExcluded", url: tab.url }, function (resp) {
    var isExcluded = !!(resp && resp.excluded);
    if (isExcluded) {
      btnTitle.textContent = "取消排除此网站";
      btnSub.textContent = "恢复下载嗅探";
    } else {
      btnTitle.textContent = "排除此网站";
      btnSub.textContent = "添加当前网站到排除列表";
    }
    excludeBtn.setAttribute("data-excluded", isExcluded ? "1" : "0");
  });
});

document.getElementById("open-options").addEventListener("click", function (e) {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
  closePopup();
});

excludeBtn.addEventListener("click", function (e) {
  e.preventDefault();
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs && tabs[0];
    if (!tab || !tab.id || !tab.url || !/^https?:/i.test(tab.url)) return;
    var isExcluded = excludeBtn.getAttribute("data-excluded") === "1";
    var msg = isExcluded
      ? { type: "neatUnexcludeCurrentPage", tabId: tab.id, url: tab.url }
      : { type: "neatExcludeCurrentPage", tabId: tab.id, url: tab.url };
    try {
      chrome.runtime.sendMessage(msg, function () {
        // 后台会更新排除列表并自动刷新当前标签页
        closePopup();
      });
    } catch (err) {
      closePopup();
    }
  });
});
